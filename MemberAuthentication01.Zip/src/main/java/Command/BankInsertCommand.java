package Command;

import java.io.IOException;
import dataControl.dao.AccountDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BankInsertCommand implements Command {

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        AccountDAO dao = new AccountDAO();
        String accCode = request.getParameter("accCode");
        String accTypeName = request.getParameter("accTypeName");
        String accPw = request.getParameter("password");
        String accName = request.getParameter("accName");
        dao.accountInsert(accCode, accTypeName, accPw, accName);
    }

    @Override
    public String getViewPage() {
        // TODO Auto-generated method stub
        return null;
    }

}
