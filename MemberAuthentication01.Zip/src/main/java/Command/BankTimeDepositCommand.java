package Command;

import java.io.IOException;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class BankTimeDepositCommand implements Command {
    String viewPage = null;

    @Override
    public void execute(HttpServletRequest request, HttpServletResponse response) {
        System.out.println("actionDo");

        String viewPage = null;
        String uri = request.getRequestURI();
        System.out.println("uri : " + uri);

        String conPath = request.getContextPath();
        System.out.println("conPath : " + conPath);

        String command = uri.substring(conPath.length());
        System.out.println("command : " + command);

        if (command.equals("/View/insert.bank")) {
            System.out.println("/View/insert.bank");
            Command bk = new BankInsertCommand();
            bk.execute(request, response);
            viewPage = "/View/accountInsertOk.jsp";

        } else if (command.equals("/View/timeDepositSelect.bank")) {
            System.out.println("/View/timeDepositSelect.bank");
            Command bk = new BankTimeDepositCommand();

            bk.execute(request, response);
            viewPage = "/View/timeDepositSelect.jsp";

        }
    }

    @Override
    public String getViewPage() {
        if (viewPage == null) {
            viewPage = "../error.jsp";
        }
        return viewPage;
    }
}
