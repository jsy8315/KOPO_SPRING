package dataControl.dto;

//
//Source code recreated from a .class file by IntelliJ IDEA

import java.sql.Timestamp;
import java.util.Random;

public class AccountDTO {
 private String accNum;
 private String bankCode;
 private String custId;
 private String accPw;
 private String accStatus;
 private String accCode;
 private String accTypeName;
 private int accBalance;
 private Timestamp accOpening;
 private Timestamp accClosure;
 private String accName;

 public AccountDTO(String accCode, String accTypeName, String accPw, String accName) {
     this.accNum = "001-" + accCode + "-" + this.generateAccountNumber();
     this.bankCode = "001";
     this.custId = "1";
     this.accPw = accPw;
     this.accStatus = "정상";
     this.accCode = accCode;
     this.accTypeName = accTypeName;
     this.accBalance = 0;
     this.accOpening = null;
     this.accClosure = null;
     this.accName = accName;
 }

 private String generateAccountNumber() {
     Random random = new Random();
     int accountNumber = random.nextInt(900000) + 100000;
     return String.valueOf(accountNumber);
 }

 public AccountDTO(String accNum, String bankCode, String custId, String accPw, String accStatus, String accCode, String accTypeName, int accBalance, Timestamp accOpening, Timestamp accClosure, String accName) {
     this.accNum = accNum;
     this.bankCode = bankCode;
     this.custId = custId;
     this.accPw = accPw;
     this.accStatus = accStatus;
     this.accCode = accCode;
     this.accTypeName = accTypeName;
     this.accBalance = accBalance;
     this.accOpening = accOpening;
     this.accClosure = accClosure;
     this.accName = accName;
 }

 public String getAccNum() {
     return this.accNum;
 }

 public void setAccNum(String accNum) {
     this.accNum = accNum;
 }

 public String getBankCode() {
     return this.bankCode;
 }

 public void setBankCode(String bankCode) {
     this.bankCode = bankCode;
 }

 public String getCustId() {
     return this.custId;
 }

 public void setCustId(String custId) {
     this.custId = custId;
 }

 public String getAccPw() {
     return this.accPw;
 }

 public void setAccPw(String accPw) {
     this.accPw = accPw;
 }

 public String getAccStatus() {
     return this.accStatus;
 }

 public void setAccStatus(String accStatus) {
     this.accStatus = accStatus;
 }

 public String getAccCode() {
     return this.accCode;
 }

 public void setAccCode(String accCode) {
     this.accCode = accCode;
 }

 public String getAccTypeName() {
     return this.accTypeName;
 }

 public void setAccTypeName(String accTypeName) {
     this.accTypeName = accTypeName;
 }

 public int getAccBalance() {
     return this.accBalance;
 }

 public void setAccBalance(int accBalance) {
     this.accBalance = accBalance;
 }

 public Timestamp getAccOpening() {
     return this.accOpening;
 }

 public void setAccOpening(Timestamp accOpening) {
     this.accOpening = accOpening;
 }

 public Timestamp getAccClosure() {
     return this.accClosure;
 }

 public void setAccClosure(Timestamp accClosure) {
     this.accClosure = accClosure;
 }

 public String getAccName() {
     return this.accName;
 }

 public void setAccName(String accName) {
     this.accName = accName;
 }
}
