package dataControl.dto;

//
//Source code recreated from a .class file by IntelliJ IDEA
//(powered by FernFlower decompiler)
//


public class TimeDepositDTO {
 private String timeDepositCode;
 private String timeDepositType;
 private String timeDepositName;

 public TimeDepositDTO(String timeDepositCode, String timeDepositType, String timeDepositName) {
     this.timeDepositCode = timeDepositCode;
     this.timeDepositType = timeDepositType;
     this.timeDepositName = timeDepositName;
 }

 public String getTimeDepositCode() {
     return this.timeDepositCode;
 }

 public void setTimeDepositCode(String timeDepositCode) {
     this.timeDepositCode = timeDepositCode;
 }

 public String getTimeDepositType() {
     return this.timeDepositType;
 }

 public void setTimeDepositType(String timeDepositType) {
     this.timeDepositType = timeDepositType;
 }

 public String getTimeDepositName() {
     return this.timeDepositName;
 }

 public void setTimeDepositName(String timeDepositName) {
     this.timeDepositName = timeDepositName;
 }
}
