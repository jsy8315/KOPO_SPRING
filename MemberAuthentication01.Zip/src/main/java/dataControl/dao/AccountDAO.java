//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package dataControl.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import dataControl.dto.AccountDTO;

public class AccountDAO {
    private static AccountDAO instance;
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    public AccountDAO() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (Exception var2) {
            var2.printStackTrace();
        }

    }


    private Connection getConnection() throws Exception {
        Context context = new InitialContext();
        DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
        return dataSource.getConnection();

    }

    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null)
                rs.close();
            if (stmt != null)
                stmt.close();
            if (conn != null)
                conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static AccountDAO getInstance() {
        if (instance == null) {
            instance = new AccountDAO();
        }
        return instance;
    }

    public boolean accountInsert(String accCode, String accTypeName, String accPw, String accName) {
        System.out.println("계좌생성시작");

        AccountDTO dto = new AccountDTO(accCode, accTypeName, accPw, accName);
        String query =
                "INSERT INTO account (accNum, bankCode, custId, accPw, accStatus, accCode, accTypeName, accBalance, accName) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            conn = getConnection();
            pstmt = conn.prepareStatement(query);
            rs = pstmt.executeQuery();

            pstmt = conn.prepareStatement(query);
            pstmt.setString(1, dto.getAccNum());
            pstmt.setString(2, dto.getBankCode());
            pstmt.setString(3, dto.getCustId());
            pstmt.setString(4, dto.getAccPw());
            pstmt.setString(5, dto.getAccStatus());
            pstmt.setString(6, dto.getAccCode());
            pstmt.setString(7, dto.getAccTypeName());
            pstmt.setInt(8, dto.getAccBalance());
            pstmt.setString(9, dto.getAccName());

            int iResult = pstmt.executeUpdate();

            return iResult > 0;

        } catch (Exception var19) {
            var19.printStackTrace();
        } finally {
            closeResources(conn, pstmt, null);
        }

        return false;
    }
}

