package dataControl.dao;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;
import dataControl.dto.TimeDepositDTO;

public class TimeDepositDAO {
    private static TimeDepositDAO instance;
    Connection conn = null;
    PreparedStatement pstmt = null;
    ResultSet rs = null;

    public TimeDepositDAO() {
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (Exception var2) {
            var2.printStackTrace();
        }

    }


    private Connection getConnection() throws Exception {
        Context context = new InitialContext();
        DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
        return dataSource.getConnection();
        
    }
    private void closeResources(Connection conn, Statement stmt, ResultSet rs) {
        try {
            if (rs != null)
                rs.close();
            if (stmt != null)
                stmt.close();
            if (conn != null)
                conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public static TimeDepositDAO getInstance() {
        if (instance == null) {
            instance = new TimeDepositDAO();
        }
        return instance;
    }

    public ArrayList<TimeDepositDTO> timeDepositSelect() {
        ArrayList<TimeDepositDTO> tDtos = new ArrayList();
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            conn = getConnection();
            stmt = conn.createStatement();
            rs = stmt.executeQuery("select * from timeDeposit");

            while(rs.next()) {
                String timeDepositCode = rs.getString("timeDepositCode");
                String timeDepositType = rs.getString("timeDepositType");
                String timeDepositName = rs.getString("timeDepositName");
                TimeDepositDTO tDto = new TimeDepositDTO(timeDepositCode, timeDepositType, timeDepositName);
                tDtos.add(tDto);
            }
        } catch (Exception var17) {
            var17.printStackTrace();
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (Exception var16) {
                var16.printStackTrace();
            }

        }

        return tDtos;
    }
}

