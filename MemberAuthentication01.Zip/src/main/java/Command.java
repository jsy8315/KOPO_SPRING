
public interface Command {

}
