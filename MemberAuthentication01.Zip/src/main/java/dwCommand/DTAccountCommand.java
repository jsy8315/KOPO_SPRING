package dwCommand;

import dwDAODTO.dwDAO;

public class DTAccountCommand {
    public boolean execute(String dAccountNumber, String transferAmount) {
        dwDAO dao = new dwDAO();
        boolean result = dao.updateDepositBalance(dAccountNumber, transferAmount);
        return result;
    }
}
