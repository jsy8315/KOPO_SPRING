package dwCommand;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public interface dwCommand {
    void execute(HttpServletRequest request, HttpServletResponse response);
}
