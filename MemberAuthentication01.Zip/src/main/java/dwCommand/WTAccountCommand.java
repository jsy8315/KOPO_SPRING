package dwCommand;

import dwDAODTO.dwDAO;

public class WTAccountCommand {
    public boolean execute(String wAccountNumber, String transferAmount) {
        dwDAO dao = new dwDAO();
        boolean result = dao.updateWithdrawBalance(wAccountNumber, transferAmount);
        return result;
    }
}
