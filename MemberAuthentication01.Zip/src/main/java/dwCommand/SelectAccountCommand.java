package dwCommand;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import dwDAODTO.BankAccount;
import dwDAODTO.dwSelectDAO;

import java.util.List;

public class SelectAccountCommand {
    private String identityNum;

    public void setParameters(String identityNum) {
        this.identityNum = identityNum;
    }

    public List<BankAccount> execute() {
        dwSelectDAO dao = new dwSelectDAO();

        // 주민등록번호로 고객 ID를 찾는다.
        String customerId = dao.findCustomerIdByIdentityNum(identityNum);

        if (customerId != null) {
            // 고객 ID로 모든 계좌를 찾는다.
            List<BankAccount> accountList = dao.findAccountsByCustomerId(customerId);
            System.out.println("02 : 고객 ID로 모든 계좌를 찾음");
            
            return accountList;
        }

        return null;
    }
}
