package dwFrontController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;

import dwCommand.SelectAccountCommand;
import dwDAODTO.BankAccount;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/select")
public class dwFrontControllerSelect extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("01 : 개별은행에 조회 요청 도착");
		BufferedReader reader = new BufferedReader(new InputStreamReader(request.getInputStream()));
        String json = reader.readLine();
        reader.close();

        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(json, JsonObject.class);

        String identityNum = jsonObject.get("identityNum").getAsString();

        SelectAccountCommand command = new SelectAccountCommand();
        command.setParameters(identityNum);
        List<BankAccount> accountList = command.execute();
        JsonArray jsonArray = new JsonArray();
        for (BankAccount account : accountList) {
            JsonObject accountObject = new JsonObject();
            accountObject.addProperty("accountNum", account.getAccountNum());
            accountObject.addProperty("bankCode", account.getBankCode());
            accountObject.addProperty("accCode", account.getAccCode());
            accountObject.addProperty("accBalance", account.getAccBalance());
            jsonArray.add(accountObject);
        }
        response.getWriter().write(jsonArray.toString());
        
        System.out.println("07 : 오픈api에 응답함");
    }

    // preflight 요청을 처리하기 위한 doOptions 메소드 추가
    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        setAccessControlHeaders(resp);
    }

    // CORS 설정을 위한 메소드
    private void setAccessControlHeaders(HttpServletResponse response) {
        response.addHeader("Access-Control-Allow-Origin", "*");
        response.addHeader("Access-Control-Allow-Methods", "GET, POST, DELETE, PUT, PATCH, HEAD");
        response.addHeader("Access-Control-Allow-Headers", "Content-Type");
        response.addHeader("Access-Control-Expose-Headers", "Access-Control-*");
        response.addHeader("Access-Control-Allow-Credentials", "true");
        response.addHeader("Access-Control-Max-Age", "60");
    }
}
