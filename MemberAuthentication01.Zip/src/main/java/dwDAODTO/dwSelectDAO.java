package dwDAODTO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class dwSelectDAO {
    private static final String DB_URL = "jdbc:oracle:thin:@dinkdb_medium?TNS_ADMIN=C:/Users/JungSuyoung/Downloads/Oracle_Cloud/Wallet_DinkDB"; // Your DB URL
    private static final String USER = "DA2317"; // Your DB username
    private static final String PASSWORD = "Data2317"; // Your DB password

    // 주민등록번호로 고객 ID를 찾는 메소드
    public String findCustomerIdByIdentityNum(String identityNum) {
        String sql = "SELECT id FROM bankcustomer01 WHERE identityNum = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, identityNum);

            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return rs.getString("id"); // Assuming 'id' is the column name for the customer id
            } else {
                return null;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // 고객 ID로 모든 계좌를 찾는 메소드
    public List<BankAccount> findAccountsByCustomerId(String customerId) {
        String sql = "SELECT accNum, bankCode, accCode, accBalance FROM account01 WHERE custId = ?";

        try (Connection conn = DriverManager.getConnection(DB_URL, USER, PASSWORD);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, customerId);

            ResultSet rs = pstmt.executeQuery();

            List<BankAccount> accountList = new ArrayList<>();
            while (rs.next()) {
                String accNum = rs.getString("accNum"); // Assuming 'accNum' is the column name for the account number
                String bankCode = rs.getString("bankCode"); // Assuming 'bankCode' is the column name for the bank code
                String accCode = rs.getString("accCode"); // Assuming 'accCode' is the column name for the account code
                String accBalance = rs.getString("accBalance"); // Assuming 'accBalance' is the column name for the account balance
                
                BankAccount account = new BankAccount(accNum, bankCode, accCode, accBalance);
                accountList.add(account);
            }

            return accountList;

        } catch (SQLException e) {
            e.printStackTrace();
            return new ArrayList<>(); // Return an empty list instead of null
        }
    }
}
