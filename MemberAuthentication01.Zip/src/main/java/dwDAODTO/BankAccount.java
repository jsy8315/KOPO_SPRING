package dwDAODTO;

//통합계좌 조회 후 보낼 계좌목록

public class BankAccount {
    private String accountNum;   // 계좌번호
    private String bankCode;     // 은행코드
    private String accCode;      // 계좌코드
    private String accBalance;   // 잔액

    public BankAccount(String accountNum, String bankCode, String accCode, String accBalance) {
        this.accountNum = accountNum;
        this.bankCode = bankCode;
        this.accCode = accCode;
        this.accBalance = accBalance;
    }

    public String getAccountNum() {
        return accountNum;
    }

    public String getBankCode() {
        return bankCode;
    }

    public String getAccCode() {
        return accCode;
    }

    public String getAccBalance() {
        return accBalance;
    }
}
