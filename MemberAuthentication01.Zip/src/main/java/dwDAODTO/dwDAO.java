package dwDAODTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class dwDAO {
    
    DataSource dataSource;
    
    public dwDAO() {
    	try {
			Context context = new InitialContext();
			dataSource = (DataSource) context.lookup("java:comp/env/jdbc/Oracle11g");
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
    
    //입금처리를 하는 메소드
    public boolean updateDepositBalance(String accountNumber, String amount) {

    	Connection connection = null;
		PreparedStatement preparedStatement = null;
	  

        try {
        	connection = dataSource.getConnection();
        	String query = "UPDATE account01 SET accBalance = accBalance + ? WHERE accNum = ?";	
        	
        	preparedStatement = connection.prepareStatement(query);
        	preparedStatement.setInt(1, Integer.parseInt(amount)); // String을 int로 변환
        	preparedStatement.setString(2, accountNumber); 

            int affectedRows = preparedStatement.executeUpdate();

            return affectedRows > 0;
        	
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		}

    //출금 처리를 하는 메소드
    public boolean updateWithdrawBalance(String accountNumber, String amount) {
    	Connection connection = null;
		PreparedStatement preparedStatement = null;

        try {
        	connection = dataSource.getConnection();
        	String query = "UPDATE account01 SET accBalance = accBalance - ? WHERE accNum = ?";
        	preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, Integer.parseInt(amount)); // String을 int로 변환
            preparedStatement.setString(2, accountNumber); 

            int affectedRows = preparedStatement.executeUpdate();

            return affectedRows > 0;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
		} finally {
			try {
				if(preparedStatement != null) preparedStatement.close();
				if(connection != null) connection.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
    }
}

